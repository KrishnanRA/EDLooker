﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EDLoo.Controllers
{
    public class EDlooController : Controller
    {
        // GET: EDloo
        public ActionResult Index()
        {
            return View();
        }
    }
}